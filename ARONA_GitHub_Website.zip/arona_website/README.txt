ARONA — GitHub Pages website

1. Extract this ZIP.
2. Open your GitHub repository.
3. Upload index.html and the assets folder (keep the folder name "assets").
4. Commit the files.
5. In repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
6. Open the published GitHub Pages link.

To change the message, edit the text inside index.html.
The image is stored at assets/arona-memory.jpg. Keep that path unchanged unless you update the image src in index.html.
